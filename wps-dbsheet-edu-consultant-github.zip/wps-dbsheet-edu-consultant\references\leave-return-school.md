﻿# School Leave-Return Management Reference

Use this reference for expert modeling of高校/学校离返校管理系统.

Default assumption: students fill leave-return information themselves through student-facing form entries. This is mandatory and should not be asked as an optional requirement. Ask only whether counselors can代填/补录 and whether parents are involved.

Do not ask school staff to choose table-count limits. Use the decomposed physical model as the default implementation. Keep the original business modules as separate tables so the school receives a complete, directly usable management system. Use the compressed 5-table model only when the user or a confirmed platform rule explicitly requires at most 5 tables.

## School Staff Interview Flow

Before emitting the leave-return schema, confirm these items with school management staff. Ask in Chinese and keep each round to at most 3 questions.

### Round 1: Scenario Scope

- 管理的是寒暑假离返校、节假日离返校、实习离校，还是开学返校？
- 是否同时管理离校、留校、中途返校、中途离校、返校？
- 是一次性专项，还是每学期复用的完整管理表？

### Round 2: Roles

- 默认学生本人通过表单自行填报；只需确认是否允许辅导员代填或补录。
- 辅导员、学院管理员、校级管理员分别需要看哪些数据？
- 是否需要家长联系方式或家长确认材料？

### Round 3: Required Records

- 离校是否要填交通方式、车次、目的地、预计到达时间？
- 留校是否要填宿舍楼、房间号、留校原因？
- 到家/返校/留校打卡是否需要上传照片？

### Round 4: Statistics

- 是否按学院、专业、班级统计需填报人数、已填报人数、未填报人数、完成率？
- 是否需要未填报清单、异常清单、返校清单？
- 是否需要自动提醒未填报学生或对应辅导员？

### Round 5: Delivery Preferences

- 表单填报入口为必需项；直接纳入方案。
- 确认管理端是否需要看板、汇总页或导出清单。
- 是否后续要直接调用 WPS/Kdocs 接口创建完整多维表并导入真实数据？
- 为完成可直接使用的多维表，需要学校提供学生、班级、学院/专业、辅导员账号，以及已有离返校/打卡记录；缺少项应列入数据采集清单。不要自行生成示例数据代替学校数据。

## Original Business Modules

The full system can include 13 modules:

1. 学院管理
2. 专业管理
3. 班级管理
4. 学生管理
5. 假期离校登记
6. 离校到家打卡
7. 假期留校登记
8. 留校每日打卡
9. 假期中途返校
10. 假期中途离校
11. 假期返校管理
12. 学生端
13. 辅导员端

## Default Decomposed Physical Model

Use this by default for complete school leave-return management. Create separate physical tables for the original business modules instead of merging them into a 5-table template:

1. `学院管理`
2. `专业管理`
3. `班级管理`
4. `学生管理`
5. `假期离校登记`
6. `离校到家打卡`
7. `假期留校登记`
8. `留校每日打卡`
9. `假期中途返校`
10. `假期中途离校`
11. `假期返校管理`
12. `学生端`
13. `辅导员端`

Default relationship direction:

- 学院管理 -> 专业管理 -> 班级管理 -> 学生管理
- 学生管理 -> 假期离校登记 / 假期留校登记 / 假期中途返校 / 假期中途离校 / 假期返校管理
- 学生管理 -> 离校到家打卡 / 留校每日打卡
- 学生端 links to student-facing form views and menus.
- 辅导员端 links to class, student, registration, check-in, exception, and statistics views.

Design principles:

- Do not collapse 学院管理、专业管理、班级管理 into one table by default.
- Do not collapse leave/stay/mid-return/mid-leave/opening-return registrations into one `假期去向登记` table by default.
- Do not collapse different check-in records into one `假期打卡记录` table by default unless the workflow is truly identical.
- Do not collapse 学生端 and 辅导员端 into one `端口菜单` table by default.
- Use lookup/count/formula fields to summarize progress upward from student/registration records to class, major, and college tables.
- Require real school data for all master and transaction records before importing records.

## Default Decomposed Table Responsibilities

Use these responsibilities when generating the full decomposed schema:

### 学院管理

Purpose: school-level college/department master data and top-level reporting unit.
Key fields: 学院名称, 学院编码, 学院负责人, 学院管理员, 联系电话, 需填报人数, 已填报人数, 未填报人数, 完成率.
Views: 学院列表, 学院填报进度, 学院异常汇总.

### 专业管理

Purpose: major/program master data under each college.
Key fields: 专业名称, 专业编码, 所属学院, 专业负责人, 年级/培养层次, 需填报人数, 已填报人数, 完成率.
Views: 专业列表, 按学院分组, 专业填报进度.

### 班级管理

Purpose: class master data and counselor management unit.
Key fields: 班级名称, 所属专业, 所属学院, 年级, 辅导员, 辅导员电话, 辅导员账号, 需填报人数, 已填报人数, 未填报人数, 完成率.
Views: 班级列表, 按学院/专业分组, 班级填报进度, 辅导员负责班级.

### 学生管理

Purpose: student master table and relation hub.
Key fields: 姓名, 学号, 手机号, 账号, 所属班级, 所属专业, 所属学院, 辅导员, 学生情况, 当前假期状态, 去向是否填报, 返校是否填报, 异常标记.
Views: 学生总表, 未填报学生, 异常学生, 按学院/班级分组.

### 假期离校登记

Purpose: records for students leaving campus during holidays.
Key fields: 学生, 学号, 班级/专业/学院 lookup, 离校时间, 预计到达时间, 到达目的地, 离校方式, 行程/车次信息, 家长联系方式, 审核状态, 审核人, 审核时间.
Views: 离校登记表单, 全部离校记录, 待审核离校, 已通过离校, 按学院/班级汇总.

### 离校到家打卡

Purpose: arrival-home confirmation after leaving campus.
Key fields: 学生, 关联离校登记, 打卡时间, 到达地点, 打卡照片, 是否按时到达, 异常说明, 确认状态.
Views: 到家打卡表单, 未到家清单, 异常到家打卡, 到家完成统计.

### 假期留校登记

Purpose: records for students staying on campus during holidays.
Key fields: 学生, 留校开始时间, 留校结束时间, 宿舍楼, 房间号, 留校原因, 校内联系人, 家长联系方式, 审核状态, 审核人.
Views: 留校登记表单, 留校学生清单, 待审核留校, 按宿舍/学院统计.

### 留校每日打卡

Purpose: daily check-in for students staying on campus.
Key fields: 学生, 关联留校登记, 打卡日期, 打卡时间, 当前位置/地点说明, 打卡照片, 是否异常, 异常说明.
Views: 留校每日打卡表单, 今日未打卡, 异常打卡, 留校打卡日历.

### 假期中途返校

Purpose: mid-holiday return-to-campus records.
Key fields: 学生, 返校时间, 返校原因, 预计在校时长, 宿舍信息, 附件证明, 审核状态, 审核人.
Views: 中途返校表单, 中途返校清单, 待审核返校, 返校日历.

### 假期中途离校

Purpose: students leaving campus again after mid-holiday return or stay.
Key fields: 学生, 离校时间, 离校原因, 目的地, 交通方式, 预计到达时间, 家长联系方式, 审核状态.
Views: 中途离校表单, 中途离校清单, 待审核中途离校, 异常中途离校.

### 假期返校管理

Purpose: opening/final return-to-school confirmation.
Key fields: 学生, 返校时间, 到校状态, 宿舍到达照片, 返校方式, 异常说明, 确认人, 确认时间.
Views: 返校登记表单, 已返校清单, 未返校清单, 异常返校, 返校统计.

### 学生端

Purpose: student-facing portal entries for form submission and personal status.
Key fields: 菜单名称, 入口类型, 关联表单/视图链接, 适用对象, 开放时间, 截止时间, 是否启用, 排序, 说明.
Views: 学生端菜单, 当前可填报事项, 已关闭事项.

### 辅导员端

Purpose: counselor-facing portal entries for review, follow-up, and class statistics.
Key fields: 菜单名称, 入口类型, 关联表/视图链接, 适用角色, 管理范围, 是否启用, 排序, 说明.
Views: 辅导员工作台, 待审核入口, 未填报跟进, 异常处理, 班级统计入口.
## Compressed 5-Table Physical Model Fallback

Use this only when the platform or user explicitly requires at most 5 tables:

1. `班级管理`
2. `学生管理`
3. `假期去向登记`
4. `假期打卡记录`
5. `端口菜单`

Do not say modules were ignored. Say:

- 学院管理 and 专业管理 are merged into `班级管理`.
- 假期离校登记、假期留校登记、中途返校、中途离校、假期返校管理 are merged into `假期去向登记` with `登记类型`.
- 离校到家打卡、留校每日打卡、返校宿舍拍照 are merged into `假期打卡记录` with `打卡类型`.
- 学生端 and 辅导员端 are merged into `端口菜单` with `端口类型`.

## Compressed Model Table Details

These details belong to the compressed fallback model above. For the default decomposed model, split organization, registration, check-in, and portal fields into their corresponding separate tables and keep the same upstream/downstream lookup/statistics logic.

### 班级管理

Purpose: organization and reporting unit.

Primary field: `班级名称`.

Fields:

- 班级名称: text, required
- 学院名称: single select or text, required
- 学科门类: single select: 人文社科类, 理工类, 医学与生命科学类, 特色与交叉学科类, 其他
- 专业名称: text, required
- 辅导员: text
- 辅导员电话: phone
- 辅导员账号: contact
- 院长: contact or text
- 需填报人数: lookup/count from 学生管理, filter 学生情况 = 正常就读
- 假期去向已填报人数: lookup/count from 学生管理, filter 假期去向是否填报 = 已填报
- 填报进度: formula 已填报人数 / 需填报人数, return 0 on error

Views:

- 班级列表: Grid
- 按学院分组: Grid grouped by 学院名称
- 填报进度看板: Kanban if supported, grouped by progress band or 学院名称

### 学生管理

Purpose: core student master table and relation hub.

Primary field: `姓名`.

Fields:

- 姓名: text, required
- 学号/工号: text, required, unique if supported
- 手机号: phone, required
- 账号: contact
- 班级: link to 班级管理
- 学院: lookup from 班级
- 专业: lookup from 班级
- 辅导员: lookup from 班级
- 院长: lookup from 班级
- 学生情况: single select: 正常就读, 因病休学, 创业休学, 自愿退学, 开除学籍, 服兵役, 境外交流
- 情况说明: long text
- 假期去向登记: link to 假期去向登记
- 假期打卡记录: link to 假期打卡记录
- 假期去向是否填报: formula
- 开学返校是否填报: formula
- 当前假期状态: formula

Formula intent:

- 假期去向是否填报: non-normal student -> 特殊情况; normal and no leave/stay registration -> 未填报; otherwise 已填报.
- 开学返校是否填报: non-normal student -> 特殊情况; no return registration -> 未填报; otherwise 已填报.
- 当前假期状态: 离校, 留校, 中途返校, 中途离校, 已返校, 待填写 based on latest related registration.

Views:

- 学生总表: Grid
- 未填报学生: Grid filtered by 假期去向是否填报 = 未填报
- 离校学生清单: Grid filtered by 当前假期状态 = 离校
- 留校学生清单: Grid filtered by 当前假期状态 = 留校
- 返校清单: Grid filtered by 开学返校是否填报 = 已填报

### 假期去向登记

Purpose: unified registration table for leave, stay, mid-return, mid-leave, and opening return.

Primary field: `登记标题`, formula/text: 学生 + 登记类型 + 登记时间.

Fields:

- 登记标题: formula or text
- 学生: link to 学生管理, required
- 姓名, 学号, 手机号, 班级, 学院, 专业, 辅导员, 院长: lookups from 学生
- 登记类型: single select: 假期离校, 假期留校, 中途返校, 中途离校, 开学返校
- 登记时间: date-time, required
- 离校时间: date-time
- 返校时间: date-time
- 预计到达时间: date-time
- 到达目的地: text
- 离校方式: single select: 火车/高铁, 长途汽车, 飞机, 地铁/公交, 同学拼车, 网约车, 家长接送, 骑行/徒步, 其他
- 行程/车次信息: long text
- 公寓楼号: text
- 房间号: text
- 留校原因: long text
- 家长姓名: text
- 家长联系方式: phone
- 备注: long text

Views:

- 全部登记: Grid
- 离校登记: Grid filter 登记类型 = 假期离校
- 留校登记: Grid filter 登记类型 = 假期留校
- 中途返校: Grid filter 登记类型 = 中途返校
- 中途离校: Grid filter 登记类型 = 中途离校
- 开学返校: Grid filter 登记类型 = 开学返校
- 去向登记表单: Form
- 按登记类型看板: Kanban grouped by 登记类型
- 离返校日历: Calendar using 登记时间 or 返校时间

### 假期打卡记录

Purpose: unified evidence/check-in table.

Primary field: `打卡标题`, formula/text: 学生 + 打卡类型 + 打卡时间.

Fields:

- 打卡标题: formula or text
- 学生: link to 学生管理, required
- 姓名, 学号, 手机号, 班级, 学院, 专业: lookups from 学生
- 打卡类型: single select: 离校到家打卡, 留校每日打卡, 返校宿舍拍照
- 打卡时间: date-time, required
- 当前位置/地点说明: text
- 打卡照片: attachment
- 备注: long text

Views:

- 全部打卡: Grid
- 到家打卡: Grid filter 打卡类型 = 离校到家打卡
- 留校每日打卡: Grid filter 打卡类型 = 留校每日打卡
- 返校宿舍拍照: Grid filter 打卡类型 = 返校宿舍拍照
- 打卡表单: Form
- 打卡日历: Calendar using 打卡时间

### 端口菜单

Purpose: merged portal/menu table for students, counselors, and admins.

Must include student-facing entries for each student form, such as 去向登记、到家打卡、留校每日打卡、返校登记. These entries are not optional in leave-return systems.

Primary field: `菜单名称`.

Fields:

- 菜单名称: text, required
- 端口类型: single select: 学生端, 辅导员端, 管理员端
- 菜单链接: URL
- 菜单封面: attachment
- 菜单说明: long text
- 排序: number
- 是否启用: checkbox

Views:

- 学生端菜单: Gallery filter 端口类型 = 学生端
- 辅导员端菜单: Gallery filter 端口类型 = 辅导员端
- 菜单列表: Grid

## Real Data Requirements

Generate at least 3 records per table:

- one leave-home student
- one stay-on-campus student
- one returned student

Place sample students in different classes when possible.

## Dashboard Metrics

If dashboards are supported, include:

- total students
- submitted students
- unsubmitted students
- leave count
- stay count
- returned count
- fill progress by college/class

If dashboards are unsupported, create summary views on `班级管理` and `学生管理`.




