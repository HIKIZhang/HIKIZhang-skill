﻿# WPS Multidimensional Table Product Capabilities Reference

Source: 金山文档 / WPS云文档《多维表格产品说明书》, https://365.kdocs.cn/l/cvBrXGemF2F4

Use this reference when users ask how WPS 多维表 works, what it can do, what it cannot do, or why a field/view/permission design is recommended.

## Product Positioning

- 多维表格 combines spreadsheet-like editing with database-style structured records.
- Each column is a typed field and each row is a record.
- Compared with ordinary spreadsheets, it emphasizes structured data entry, consistent field types, multi-view collaboration, and scenario-based management applications.
- It is suitable for school management systems that need standardized collection, follow-up, statistics, role-based views, and shared form entries.

## Field Capabilities

Common field categories include:

- Basic text/data: 文本, 富文本, 日期, 时间, 数值, 货币, 百分比, 身份证, 电话, 邮箱, 超链接, 地址.
- Selection and status: 复选框, 单选项, 多选项, 等级, 进度.
- Attachments and identity: 图片和附件, 编号, 联系人.
- Computed and relational data: 公式, 双向关联, 引用.
- System fields: 创建者, 创建时间, 最后修改者, 修改时间.
- Automation-related field: 自动任务.

Design guidance:

- Use typed fields to prevent messy data entry. For example, 学号/单据号 should often be text, 手机号 should be phone, 状态 should be single select, 照片/证明 should be attachment, 负责人 should be contact.
- Use 关联 to choose records from another table. By default, the associated record displays its first field.
- Use 引用 fields to bring other fields from associated records into the current table, such as 学院、专业、辅导员 phone, or student account.
- Use 编号 for system-generated unique record identifiers. It cannot be manually changed and does not automatically backfill after deletion.

## Formula Boundaries

- Formula fields calculate per row after being configured.
- A formula can reference fields in the same record/row.
- Do not promise formulas that calculate by directly referencing an entire column or another table/sheet unless the calculation can be implemented through relation, lookup/count, or product-supported summary features.
- For progress calculations, prefer relation/lookup/count fields plus a row formula on the management unit table.

## View Capabilities

All views are based on the same source data. Changing source records updates the views automatically. View filters, sorting, grouping, and display choices are independent per view.

Common view types and prerequisites:

- 表格视图: default and broadly suitable for source data storage; supports filtering, sorting, grouping.
- 看板视图: displays cards by group; requires a single-select field as grouping basis.
- 画册视图: best when records include images/attachments and need card-style display.
- 表单视图: creates an information collection page based on an existing data table; submitted data writes back to the table. Usually shared separately for others to fill in.
- 甘特视图: timeline display; requires start and end date fields.
- 查询视图: lets users query records through defined query conditions and visible fields; useful for data publication or self-service lookup.
- 日历视图: mention only when supported in the current product environment; if uncertain, say availability depends on the current WPS version.

## Filtering, Sorting, and Grouping

- Filtering conditions are view-specific. Multiple filters may require all conditions by default or any condition if configured.
- Contact/date fields can support dynamic conditions such as current user or today, depending on product support.
- Sorting is view-specific and can be set to automatic sorting when records should always stay ordered.
- Grouping is mainly used in table views and is view-specific.

## Forms and Collection

- Form views are appropriate for student-facing and staff-facing information collection.
- Submitted form data is written back into the underlying data table.
- For school leave-return scenarios, student-facing forms are mandatory design elements.
- If users ask whether students need to enter the full database, explain that students normally only use shared form/entry views, while administrators manage the full data tables and dashboards.

## Sharing and Permissions

The product supports collaboration through document sharing and view sharing:

- Share the whole document when collaborators need access to multiple tables/views.
- Share a specific view when collaborators should only work in one page or should not see unrelated data.
- View sharing can be used with permissions such as view-only/editable, visible record scope, editable fields, and whether records can be added/deleted, depending on product support.

Mention product roles when useful:

- 管理员
- 编辑者
- 填报者
- 查看者
- 游客

School design guidance:

- Use shared form views for students.
- Use counselor views filtered by counselor/current user or assigned class when possible.
- Use college/school administrator views for cross-class statistics and exceptions.
- Do not over-promise record-level or field-level permissions without checking current product/API support; phrase as a design goal or product-supported configuration when available.

## Import and Export

- WPS 多维表 can import data from existing spreadsheets and recognize suitable field types.
- A current view can be exported to an ordinary spreadsheet.
- Full export of an entire multidimensional table may depend on current product support; do not assume it is always available.

For complete school builds:

- Ask the school for real source data files before importing records.
- Provide import templates or column lists for each table.
- Do not generate production records from fictional demo data.

## Automation

- Automatic tasks can notify specified contacts when configured conditions are triggered, such as a field/status change.
- Use automation suggestions for reminders, status changes, overdue follow-up, and counselor notifications.
- Do not promise complex workflow automation beyond product support unless it can be handled by WPS/Kdocs APIs or external integration.

## Mobile Use

- WPS 多维表 supports mobile operation.
- Users can update records and upload phone-captured materials from mobile devices.
- This is useful for school scenarios such as 到家打卡, 宿舍拍照, 现场确认, and counselor follow-up.

## How To Answer Product-Usage Questions

When users ask “能不能做/怎么用/有什么限制”:

1. Answer from product capability first in plain school-management language.
2. Map the capability to the current scenario, such as 学生表单, 辅导员视图, 学院汇总, 权限隔离, 自动提醒.
3. State prerequisites, such as required field types for kanban/gantt/query/form views.
4. State boundaries clearly, especially formula row-only behavior, view-specific filters, shared source data, and real data requirements.
5. If the user asks for direct creation or inspection in WPS/Kdocs, use the `kdocs` skill/tools and verify the actual file/schema before making changes.
