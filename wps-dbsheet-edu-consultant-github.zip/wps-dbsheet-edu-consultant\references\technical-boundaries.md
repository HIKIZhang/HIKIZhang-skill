# Technical Boundaries for Automated Dbsheet Delivery

Use this reference when estimating what the agent can create, modify, copy when supported, import, synchronize, or verify automatically for a WPS multidimensional table, and what requires verification, manual configuration, existing templates, or future API support.

## Interface Source Boundary

Current automated creation capability is based on the available `kdocs` / `dbsheet` interface exposed by `kdocs-cli`.

Do not describe unverified `wps365` dedicated APIs as confirmed capabilities. If a user or implementation plan mentions WPS365 APIs, state that the current assessment is based on `kdocs` / `dbsheet`; WPS365-specific field, view, permission, automation, dashboard, or portal capabilities must be rechecked after that interface is available and tested.

## Generally Automatable with kdocs/dbsheet

These parts are suitable for direct agent delivery after requirements, strategy, and real data are ready:

- Locate and read existing WPS/Kdocs files when the user has access.
- Copy or save-as existing dbsheet templates only after verifying that the current interface supports file-level copy/save-as for that file type.
- Create data tables such as 学院管理、专业管理、班级管理、学生管理、各类登记/打卡表、学生端、辅导员端.
- Create fields: text, multiline text, date/time, number, percentage, phone, email, URL, checkbox, single select, multiple select, contact, attachment, link, lookup, formula, auto number, created/modified system fields.
- Create basic views: Grid, Form, Kanban, Gallery, Gantt, Calendar, subject to required fields and actual API support.
- Create records by importing school-provided real data.
- Update selected tables, fields, views, and records in an existing or copied dbsheet after reading schema and confirming the edit scope.
- Synchronize source data into target tables when unique keys, field mapping, append/update policy, and verification counts are defined.
- Recreate a target dbsheet from a readable template schema when file-level copy/save-as is unavailable and the required template parts are supported by create/update/import APIs.
- Create relation and lookup fields after target tables/views/fields exist and `get_schema` has returned IDs.
- Open/share views and form views when all required share parameters are known.
- Create or update content-permission roles when the document has advanced permission/content permission enabled and member/field IDs are available.
- Create webhooks for external integrations when a trusted public callback URL exists.

## Needs Verification or Follow-up Configuration

These can be designed by the agent, but should not be over-promised as fully automatic until verified in the actual document:

- Filtered views such as 未填报学生、待审核离校、辅导员本班学生、学院异常清单. The current `create_view` interface is basic; complex filters/sorts/grouping may need front-end configuration or later `update_view` support.
- Kanban/Gantt/Calendar/Query view deep settings. The agent must ensure prerequisite fields exist, but some detailed mapping or query conditions may need manual adjustment.
- Form presentation details such as question text, descriptions, required/hidden fields, and form theme. The form interfaces exist, but actual metadata shape must be read and verified per form view.
- Advanced permissions by counselor/college/class. This depends on advanced permission being enabled, real WPS member IDs, field IDs, and reliable record filters.
- Contact fields. Writing contact values usually requires real organization member IDs, not just names or phone numbers.
- Attachment fields. Historical photo/material import requires real uploaded file objects or upload IDs. For current processes, prefer student form upload.
- Formula and lookup statistics. Formula fields are row-level; cross-table or aggregate progress should rely on relation/lookup/count plus formula where supported, then be verified through schema/readback.

## Usually Not Fully Automatable from Scratch

These should be positioned as design goals, manual configuration tasks, or template-based follow-up unless a tested interface is available:

- Creating a full dashboard from scratch with chart cards, metrics, layouts, and data sources. Current interface can list/copy dashboards, not fully author every dashboard component.
- Copying or saving-as a dbsheet template when the current interface does not expose a tested file-level copy/save-as capability for dbsheet files.
- Safely performing broad structural edits to a complex template without first reading helper/config tables, schema, formulas, relation fields, lookup fields, and sample records.
- Creating product-native automatic notification tasks exactly like the front-end “自动任务”. Webhooks are available for external callbacks, but they are not the same as in-product reminder workflows.
- Building a full application-style student/counselor portal. The agent can create 学生端/辅导员端 menu tables and shared links, but not necessarily a custom app homepage with dynamic buttons and navigation.
- Producing official production records without school-provided real data.

## Recommended Customer-Facing Delivery Language

When explaining delivery scope, group capabilities like this:

- 可自动创建/修改/同步：表、字段、基础视图、表单、关联、引用、公式、记录导入、按唯一键追加或更新记录、分享链接；复制/另存多维表模板需先验证接口是否支持。
- 模板能力不足时的自动替代：读取模板结构并通过新建表、字段、视图、公式、关联、记录导入等接口重建目标多维表。
- 可设计但需验证/补配置：复杂筛选视图、复杂权限、甘特/查询视图细节、表单展示细节、联系人字段、附件历史导入。
- 通常不能从零完全自动生成：仪表盘图表、产品内自动任务、完整门户式学生端/辅导员端、没有真实数据的正式业务记录。

Always tell the user what prerequisite is missing rather than silently replacing a blocked feature with fictional data or an unsupported capability.
