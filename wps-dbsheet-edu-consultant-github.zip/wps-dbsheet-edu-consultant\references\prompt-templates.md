﻿# Prompt Templates

Use these templates as starting points. Replace placeholders and remove unsupported features according to platform constraints.

Customer-facing prompts in this reference should be emitted in Chinese by default. Keep table names, field names, view names, and business status values in Chinese unless the user asks otherwise.

Sections marked executor-facing are internal execution requirements, not customer conversation copy. Do not emit executor-facing templates directly to the customer unless the user explicitly asks for implementation details. Customer-facing messages should show only the confirmed business solution, required materials, risk confirmations, and final delivery result.

## Requirement Interview Opening

```text
您好，我是 WPS教育多维表场景专家。我会先了解贵校的管理需求，再为您整理 WPS 多维表方案。
为了避免后面返工，我先确认 3 件事：
1. 这套表主要管理哪个学校事项？例如离返校、请假、宿舍、活动报名、学生台账等。
2. 默认由学生本人通过表单填报。是否还需要辅导员代填、补录或审核？
3. 管理端主要需要看哪些结果？例如未填报清单、按学院/班级完成率、异常学生清单、返校统计。
```

## Leave-Return Scenario Expert Opening

```text
您好，我是 WPS教育多维表场景专家。我会先了解贵校离返校管理的关键需求，再为您整理一套可落地的多维表方案。
开始前，我想先确认几个管理问题：
1. 这套离返校管理主要覆盖寒暑假、节假日，还是日常临时离校？
2. 是否需要辅导员代填、补录或审核学生提交的信息？
3. 管理端重点需要哪些结果：未填报清单、按学院/班级完成率、异常学生清单，还是返校统计？
```

## Post-Interview Solution Summary

Use this after requirements are confirmed, before choosing the final execution strategy.

```text
根据刚才确认的需求，我建议将这套离返校管理设计为几个核心部分：学生基础信息、班级/学院管理、离返校登记、打卡记录和端口菜单。

这套方案可以支持：
- 学生提交离校、留校、返校等信息
- 辅导员查看本班填报和异常情况
- 管理端按学院、班级统计完成率
- 生成未填报、离校、留校、返校等管理清单

如果这个方向符合您的预期，我将继续列出需要提供的数据清单和优先级；数据校验通过后再创建多维表并导入真实数据。
```

## Post-Confirmation Data Request

Use this after the user confirms the business solution. Keep the request concise and prioritized.

```text
方案已确认。接下来为了生成可直接使用的多维表，需要您按优先级提供以下数据：

优先级 1：必须提供
- {required_master_data}
- {required_business_records}

优先级 2：建议提供
- {recommended_configuration_data}

优先级 3：可选
- {optional_history_or_demo_data}

请优先提供已有表格文件或在线表链接。我会先解析表头、样例行和记录数，检查必填字段、唯一键、关联字段和日期/选项格式；校验通过后再自动建表并导入数据。

如果暂时没有完整数据，也可以先交付空表结构、表单、视图和导入模板；正式业务记录不会由我编造。
```

## Internal Execution Strategy Notes

Use this internally after the user confirms the solution. Do not emit this section to the customer unless the user explicitly asks for implementation details.

```text
内部执行策略：{模板派生交付/重新新建/补建表并同步数据}
模板派生子路径：{copy-template-then-modify/recreate-from-template-schema/user-provided-template-copy}

选择原因：
1. {reason_1}
2. {reason_2}
3. {reason_3}

不采用其他方式的原因：
- 模板派生交付：{why_or_why_not}
- 重新新建：{why_or_why_not}
- 补建表并同步数据：{why_or_why_not}

需要向用户确认的只限业务材料或风险动作：
1. {confirmation_1}
2. {confirmation_2}
3. {confirmation_3}

对用户表达时，不要求用户选择技术路径，只说明交付内容、所需材料、风险确认和最终结果。
```

## Template-Derived Delivery Requirements

Executor-facing only. Use when a trusted template covers most of the confirmed solution. Do not emit this template directly to the customer.

```text
请基于现有 WPS/Kdocs 多维表模板完成模板派生交付，不要直接修改模板本体。

【执行前置断言】
- assert_solution_confirmed：业务方案已由用户确认，或用户明确授权按列出的假设继续。
- assert_data_request_completed：方案确认后的数据清单已发出，用户已提供必要数据，或确认先交付空结构/导入模板。
- assert_validation_passed：用于正式导入的数据已解析并校验通过。
- assert_no_blocking_issues：不存在未解决的必填字段缺失、唯一键为空/重复、关联匹配失败、日期/选项格式错误、联系人/附件前提缺失等阻塞问题。
- 如果任一断言不成立，停止执行并输出缺失确认、缺失数据或需修正问题；不要调用创建、删除、导入、分享或权限修改接口。

【模板信息】
- 模板名称/链接：{template_name_or_url}
- 目标交付文件名称：{target_file_name}

【已确认方案】
{confirmed_solution}

【能力探测与子路径选择】
1. 先验证当前 WPS/Kdocs 接口是否支持多维表模板的文件级复制或另存。
2. 如果支持复制/另存：先复制模板，所有修改都在副本中完成，不直接修改模板本体。
3. 如果不支持复制/另存：读取模板的表清单、字段、视图、公式、关联字段、Lookup 字段、表单/入口、权限/链接配置和配置说明表；将模板作为结构参考，新建目标多维表，并通过支持的创建/更新/导入接口重建可自动实现的结构。
4. 如果模板包含当前接口无法安全重建但必须保留的复杂仪表盘、复杂表单展示、复杂权限或门户式导航，则暂停自动重建，只向用户请求一个可编辑的模板副本或目标文件。

【读取要求】
读取模板或副本的文件信息、表清单、字段、视图、公式、关联字段、Lookup 字段、表单/入口、权限/链接配置，以及模板内已有的配置说明表。

【修改范围】
- 需要修改：{allowed_changes}
- 需要新增：{new_tables_fields_views}
- 需要保留：公式、Lookup、关联字段、系统字段、既有关系、关键表单和统计视图，除非方案明确要求改动。
- 禁止操作：不要修改模板本体，不要删除未确认的表/字段/视图，不要自动开放分享链接。

【数据处理】
- 数据来源：{source_data_files_or_links}
- 数据优先级：{data_priority}
- 字段映射：{field_mapping}
- 唯一键：{unique_keys}
- 导入策略：{import_policy}
- 数据校验结果：{validation_result}
- 阻塞问题：{blocking_data_issues}

【确认事项】
在执行清空记录、覆盖字段、修改权限、开放分享链接前，必须先列出影响范围并等待用户确认。

【校验要求】
完成后回读校验：文件名称、表结构、字段类型、公式/Lookup/关联关系、视图、导入记录数、抽样记录、入口链接和权限状态。
```

## New Dbsheet Creation Requirements

Executor-facing only. Use when the internal strategy is to create a new WPS/Kdocs multidimensional table. Do not emit this template directly to the customer.

```text
请根据以下要求创建一个 WPS 多维表。

【执行前置断言】
- assert_solution_confirmed：业务方案已由用户确认，或用户明确授权按列出的假设继续。
- assert_data_request_completed：方案确认后的数据清单已发出，用户已提供必要数据，或确认先交付空结构/导入模板。
- assert_validation_passed：用于正式导入的数据已解析并校验通过。
- assert_no_blocking_issues：不存在未解决的必填字段缺失、唯一键为空/重复、关联匹配失败、日期/选项格式错误、联系人/附件前提缺失等阻塞问题。
- 如果任一断言不成立，停止执行并输出缺失确认、缺失数据或需修正问题；不要调用创建、删除、导入、分享或权限修改接口。

【多维表名称】
{name}

【建表原则】
按业务解构创建多张物理表，优先保证学校管理流程完整、表职责清晰、关联关系明确。新建离返校系统不要默认压缩成 5 张表；只有在内部确认存在接口约束、实现可靠性原因或用户明确业务限制时，才允许紧凑物理结构，并必须通过类型字段、筛选视图、表单和端口菜单保留全部业务模块。

【业务目标】
{business_goal}

【使用角色】
{roles}

【建模策略】
{modeling_strategy}
默认采用解构模型：主数据、业务登记、打卡日志、学生端、辅导员端分别建表。仅在内部交付策略确认紧凑结构更可靠或存在明确限制时才使用合并策略。

【表结构】
表 1：{table_name}
用途：{purpose}
主字段：{primary_field}
字段：
- {field}: {type}; {required/options/relation/lookup/formula}
视图：
- {view}: {view_type}; {filter/group/sort}

【表间关系】
{relations}

【公式和统计】
{formulas}

【真实数据要求】
本任务目标是创建可直接使用的完整多维表。不要自行生成示例学生、班级、手机号、账号或业务记录。
方案确认后请列出每张表需要学校提供的源数据字段、建议导入文件、必填列、唯一键和缺失数据处理方式。只有在学校提供真实数据并校验通过后，才导入记录。
如用户明确要求演示数据，必须标注为“非生产演示数据”，不得作为正式交付数据。

【输出要求】
输出每张表的字段、视图、关联关系、公式、权限、自动化建议和真实数据导入清单。不要输出与建表无关的解释，不要编造正式业务数据。
```

## Partial Build And Data Sync Requirements

Executor-facing only. Use when an existing dbsheet/source file should be preserved and extended, or when data must be synchronized into WPS 多维表. Do not emit this template directly to the customer.

```text
请基于现有 WPS/Kdocs 文件完成补建表、字段、视图，并将用户提供的数据同步到目标多维表。

【执行前置断言】
- assert_solution_confirmed：业务方案已由用户确认，或用户明确授权按列出的假设继续。
- assert_data_request_completed：方案确认后的数据清单已发出，用户已提供必要数据，或确认先交付空结构/导入模板。
- assert_validation_passed：用于正式导入或同步的数据已解析并校验通过。
- assert_no_blocking_issues：不存在未解决的必填字段缺失、唯一键为空/重复、关联匹配失败、日期/选项格式错误、联系人/附件前提缺失等阻塞问题。
- 如果任一断言不成立，停止执行并输出缺失确认、缺失数据或需修正问题；不要调用创建、删除、导入、分享或权限修改接口。

【现有文件/数据源】
- 目标多维表：{target_dbsheet}
- 数据源：{source_files_or_tables}

【已确认方案】
{confirmed_solution}

【读取要求】
先读取目标多维表的文件信息、表清单、字段、视图、公式、关联字段、Lookup 字段和现有记录样本；读取数据源表头、样例行和记录数。

【数据校验要求】
- 校验必填字段是否存在。
- 校验唯一键是否为空或重复。
- 校验关联字段是否能匹配目标表记录。
- 校验选项值、日期/时间、手机号、邮箱、联系人、附件等字段格式。
- 输出可导入记录数、需修正记录数和阻塞问题；阻塞问题未解决前不要导入正式记录。

【补建/修改范围】
- 新增表：{new_tables}
- 新增字段：{new_fields}
- 新增视图：{new_views}
- 保留内容：{preserve_existing}

【同步规则】
- 唯一键：{unique_keys}
- 字段映射：{field_mapping}
- 写入策略：{append_update_policy}
- 去重规则：{dedupe_policy}
- 删除策略：{delete_policy_or_none}
- 异常数据处理：{invalid_data_policy}

【确认事项】
覆盖已有记录、清空表、删除字段/视图、批量开放权限前，必须先确认。

【校验要求】
完成后回读校验：新增结构、同步记录数、失败记录、抽样记录、统计视图结果和关键公式结果。
```

## Decomposed Leave-Return Prompt Guardrails

Add these constraints when the generator incorrectly compresses the decomposed leave-return system into 5 tables:

```text
注意：请按业务解构创建完整离返校管理多维表，不要默认压缩成 5 张表。
必须分别创建并设计以下模块：学院管理、专业管理、班级管理、学生管理、假期离校登记、离校到家打卡、假期留校登记、留校每日打卡、假期中途返校、假期中途离校、假期返校管理、学生端、辅导员端。

不要输出“已将原业务模块合并进 5 张核心表”。只有在用户明确要求限制表数量时，才允许合并。
学生本人填报入口是必需项。必须为离校登记、留校登记、中途返校、中途离校、返校管理和相关打卡表创建学生可用的表单视图，并在“学生端”中创建对应入口；在“辅导员端”中创建审核、未填报、异常、统计等管理入口。
```

## Prompt Repair Pattern

When the generated result is wrong, write:

```text
上一版生成结果的问题：
1. {issue}

请重新生成，并严格遵守：
1. {corrected_constraint}
2. {merge_or_field_rule}
3. {negative_instruction}

以下是修正后的完整建表要求：
{full_prompt}
```





