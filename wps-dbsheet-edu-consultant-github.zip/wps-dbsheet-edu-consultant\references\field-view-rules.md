﻿# Field and View Rules

Use this checklist before emitting a WPS dbsheet blueprint or creation prompt.

For Chinese users, output field names and view names in Chinese. Preserve English only for API enum values or platform-specific identifiers.

## Field Type Mapping

- names, titles, class names: text or single-line text
- descriptions, reasons, notes, route details: long text
- phone numbers: phone
- emails: email
- links: URL
- people inside the WPS organization: contact
- statuses and exclusive categories: single select
- tags and non-exclusive labels: multi select
- dates, arrival times, check-in times: date/date-time
- photos, evidence, files: attachment
- yes/no flags: checkbox
- counts and amounts: number
- progress: percentage or formula formatted as percentage
- cross-table connection: link/association
- copied related values: lookup
- computed status: formula

## View Preconditions

- Grid: always safe and should be the first view.
- Form: use for intake/registration when supported.
- Kanban: requires a select/status/type field.
- Calendar: requires a date/date-time field.
- Gallery: works best with attachment/image plus title/description fields.
- Gantt: requires start and end date fields.

## Relation Checklist

- Multi-table designs need at least one relation field.
- Prefer a single hub entity table for operational systems.
- Add lookup fields only after the relation source exists.
- Avoid relation cycles unless they support a clear business need.

## Formula Checklist

- State formulas should handle empty values.
- Progress formulas should divide safely and return 0 on error.
- Text parsing formulas are fragile; prefer relation/lookup if data is maintained manually.
- If the target generator may not support exact formula syntax, describe formula intent in plain language plus an example.

## Prompt Quality Checklist

Before finalizing a prompt, verify:

- table count matches platform limit
- every requested module is represented by a table, type field, or filtered view
- every non-Grid view has the fields it needs
- business roles have appropriate views
- prompt does not invent production data; it requests real source data or provides an import checklist
- relation fields are named clearly
- no instruction says to ignore a requested module unless the user explicitly agreed

